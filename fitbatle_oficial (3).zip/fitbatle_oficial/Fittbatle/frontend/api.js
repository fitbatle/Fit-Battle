const HOST_API = window.location.hostname || 'localhost';
const PORTAS_FRONTEND_DEV = new Set(['5500', '5501']);
const API_URL = window.FITBATTLE_API_URL
  ? window.FITBATTLE_API_URL
  : (PORTAS_FRONTEND_DEV.has(window.location.port)
    ? 'http://' + HOST_API + ':5000/api'
    : window.location.origin + '/api');
const ORIGEM_API = API_URL.replace(/\/api\/?$/, '');
const CHAVE_SESSAO = 'fitbattle_sessao';
const CHAVE_SESSAO_ANTIGA = 'fitbattle_usuario';
const PAGINA_LOGIN = 'login.html';
const PAGINA_INICIAL = 'feed.html';

function armazenamentosDisponiveis() {
  const lista = [];
  try { if (typeof sessionStorage !== 'undefined') lista.push(sessionStorage); } catch (e) {}
  try { if (typeof localStorage !== 'undefined') lista.push(localStorage); } catch (e) {}
  return lista;
}

function armazenamentoDaSessao() {
  const lista = armazenamentosDisponiveis();
  for (let i = 0; i < lista.length; i++) {
    try {
      if (lista[i].getItem(CHAVE_SESSAO)) return lista[i];
    } catch (e) {}
  }
  return null;
}

// Só o necessário para montar o cabeçalho e identificar o usuário fica no navegador.
// Dados pessoais (e-mail, nascimento, peso, altura, cidade...) vêm sempre da API.
const CAMPOS_USUARIO_SESSAO = ['id', 'nome', 'foto', 'nivel', 'xp'];

function resumirUsuario(usuario) {
  if (!usuario) return null;
  const resumo = {};
  CAMPOS_USUARIO_SESSAO.forEach(function (campo) {
    if (usuario[campo] !== undefined) resumo[campo] = usuario[campo];
  });
  return resumo;
}

function temCamposExtras(usuario) {
  return Object.keys(usuario).some(function (campo) {
    return CAMPOS_USUARIO_SESSAO.indexOf(campo) === -1;
  });
}

function gravarSessao(armazenamento, token, usuario) {
  try {
    armazenamento.setItem(CHAVE_SESSAO, JSON.stringify({ token: token, usuario: resumirUsuario(usuario) }));
  } catch (e) {}
}

function lerSessao() {
  const armazenamento = armazenamentoDaSessao();
  if (!armazenamento) return null;
  try {
    const sessao = JSON.parse(armazenamento.getItem(CHAVE_SESSAO));
    if (!(sessao && sessao.token && sessao.usuario)) return null;
    // Sessões salvas por versões antigas guardavam o perfil inteiro: enxuga na primeira leitura.
    if (temCamposExtras(sessao.usuario)) {
      sessao.usuario = resumirUsuario(sessao.usuario);
      gravarSessao(armazenamento, sessao.token, sessao.usuario);
    }
    return sessao;
  } catch (e) {
    return null;
  }
}

function salvarSessao(token, usuario, lembrar) {
  const persistente = lembrar === true;
  const destino = persistente ? localStorage : (typeof sessionStorage !== 'undefined' ? sessionStorage : localStorage);
  limparSessao();
  gravarSessao(destino, token, usuario);
}

function atualizarTokenDaSessao(token) {
  const armazenamento = armazenamentoDaSessao();
  const sessao = lerSessao();
  if (!armazenamento || !sessao) return;
  gravarSessao(armazenamento, token, sessao.usuario);
}

function atualizarUsuarioDaSessao(usuario) {
  const armazenamento = armazenamentoDaSessao();
  const sessao = lerSessao();
  if (!armazenamento || !sessao) return;
  gravarSessao(armazenamento, sessao.token, usuario);
}

function limparSessao() {
  armazenamentosDisponiveis().forEach(function (armazenamento) {
    try {
      armazenamento.removeItem(CHAVE_SESSAO);
      armazenamento.removeItem(CHAVE_SESSAO_ANTIGA);
    } catch (e) {}
  });
}

function usuarioDaSessao() {
  const sessao = lerSessao();
  return sessao ? sessao.usuario : null;
}

function exigirLogin() {
  const usuario = usuarioDaSessao();
  if (!usuario) {
    window.location.href = PAGINA_LOGIN;
    return null;
  }
  return usuario;
}

function encerrarSessao() {
  limparSessao();
  window.location.href = PAGINA_LOGIN;
}

const MENSAGEM_SEM_CONEXAO = 'Não foi possível falar com o servidor. Tente novamente.';

class ErroDeConexao extends Error {
  constructor() {
    super(MENSAGEM_SEM_CONEXAO);
    this.name = 'ErroDeConexao';
  }
}

async function api(caminho, opcoes) {
  const config = Object.assign({}, opcoes);
  const cabecalhos = Object.assign({}, config.headers);
  const sessao = lerSessao();
  if (sessao) cabecalhos['Authorization'] = 'Bearer ' + sessao.token;
  config.headers = cabecalhos;

  let resposta;
  try {
    resposta = await fetch(API_URL + caminho, config);
  } catch (erro) {
    throw new ErroDeConexao();
  }
  if (resposta.status === 401) encerrarSessao();
  if (resposta.status >= 500) throw new ErroDeConexao();
  return resposta;
}

function mostrarFalhaDeCarregamento(aoTentarDeNovo) {
  document.querySelectorAll('body *').forEach(function (elemento) {
    if (elemento.childElementCount === 0 && /^carregando/i.test(elemento.textContent.trim())) {
      elemento.textContent = /^(H[1-6]|SPAN)$/.test(elemento.tagName) ? 'Indisponível no momento' : MENSAGEM_SEM_CONEXAO;
    }
  });
  let bloco = document.getElementById('falhaDeCarregamento');
  if (bloco) bloco.remove();
  bloco = document.createElement('div');
  bloco.id = 'falhaDeCarregamento';
  bloco.className = 'card card--interno estado-falha';
  bloco.setAttribute('role', 'alert');
  const texto = document.createElement('p');
  texto.textContent = MENSAGEM_SEM_CONEXAO;
  const botao = document.createElement('button');
  botao.type = 'button';
  botao.className = 'btn btn--secundario btn--pequeno';
  botao.textContent = 'Tentar de novo';
  botao.addEventListener('click', function () {
    bloco.remove();
    aoTentarDeNovo();
  });
  bloco.append(texto, botao);
  const principal = document.querySelector('main') || document.body;
  principal.insertBefore(bloco, principal.firstChild);
}

async function atualizarSessaoPelaApi() {
  const resposta = await api('/eu');
  if (!resposta.ok) return null;
  const dados = await resposta.json();
  atualizarUsuarioDaSessao(dados.usuario);
  return dados.usuario;
}

const ESCAPES_HTML = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };

function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, function (caractere) {
    return ESCAPES_HTML[caractere];
  });
}
